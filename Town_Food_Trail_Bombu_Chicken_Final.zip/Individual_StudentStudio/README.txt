PROJECT: Town Food Trail
THEME: Town Food Trail — local place
FEATURED FOOD PLACE: Bombu Chicken
STUDENT: Mary Mae Arcipe
PROJECT TYPE: Individual project
ROLE: Mary Mae Arcipe — planned and created all pages, HTML, CSS, content, images, and audio.

PAGES:
1. index.html — Home page and introduction to the food trail
2. about.html — About the project and tips before visiting
3. projects.html — Featured food stop: Bombu Chicken
4. contact.html — HTML contact form

FOLDERS:
css/ — one external stylesheet
images/ — original SVG food illustration
media/ — short original WAV audio

HOW TO VIEW:
Open index.html in a web browser. Use the navigation menu to visit all four pages.

PROJECT FEATURES:
Semantic HTML5 structure, working page navigation, responsive viewport meta tag, CSS variables, Flexbox/Grid layouts, phone and desktop breakpoints, hover/focus states, image alt text, figure and figcaption, audio controls, and a contact form with labels, text input, email input, select, textarea, and submit button.

IMPORTANT:
This is an individual educational project and is not the official website of Bombu Chicken. No unverified menu, price, address, or opening-hour information is claimed. The contact form is a front-end demonstration and does not send or store messages.

EDITOR REQUIREMENT:
The project guidelines specify that the website must be built and edited in Visual Studio only.
